---
name: research-paper-pdf
description: Turn a markdown research or architecture paper into a polished PDF in the established Maxey0 "Execution-Space" format — serif body, burnt-sienna accents, inline matplotlib architecture figures, callout boxes, and zebra tables. Expands thin or listed sections into full prose, verifies spelling, glyphs, and layout, and supports an iterative rebuild pipeline. Use when the user asks to typeset, format, resynthesize, or upgrade a paper into that PDF report format, or references the format of a prior paper built this way.
---

# research-paper-pdf

Produce a print-quality PDF research paper in the house "Execution-Space" format from a
markdown/plain-text source, expanding the source's thin or bullet-listed sections into
full prose, rendering inline **architecture** figures, and verifying the result before
delivery. The two companion papers already built this way — *Maxey0 System One* and
*Structured Context Worlds* — define the target look.

## 0. Zero-shot intake — get this before building; ask only if missing

The skill runs zero-shot when the request already carries enough context. If any of the
following is unknown and can't be inferred from the source, **ask the user once** (batch
the questions) rather than guessing:

- **Source + current state** — the markdown/text of the paper, and where it stands
  (rough draft? complete but unformatted? needs sections expanded?).
- **Desired changes** — expand listed sections? resynthesize/merge drafts? tighten?
  add figures only? A one-line "what should be different from the source" is enough.
- **Byline & authorship** — exact author names/order, contact, date, and what the agent's
  own co-title should be (see §5). Preserve the source's stated lead author.
- **Target length / depth** — or "match the companion paper." Never pad to hit a number.
- **Spelling** — American or British (default: match the source; these papers use American).
- **Empirical results?** — does the paper claim measured results, or is it a proposal?
  This decides whether any chart may show data (see §4).
- **Output filename** and where to deliver.

If the user says "just do it" / "use your judgment," take the most reasonable reading,
state the assumptions you made at the top of your report, and proceed.

## 1. Pipeline & caching (working memory)

Keep three artifacts in the working directory across turns; **this is the cache** —
never rebuild from scratch when iterating:

```
build_pdf.py        # the harness + the paper's content (from assets/build_harness.py)
make_figs.py        # the figure generators      (from assets/figures_harness.py)
fig/                # rendered PNGs (or fig_<slug>/ if several papers share a dir)
```

Iterative edits: **edit the script, re-run it**, keep the same `OUTPUT_PDF` path so a
re-delivery replaces the prior file. For a paper being revised across sessions, the same
two scripts + figure dir are the resumable state. When the user asks for "the same format
as last time," copy these two files and swap the CONTENT block.

Recommended order every run: **analyze source → plan figures+tables → build figures →
review contact sheet → build PDF → verify → deliver.** Build figures *before* prose only
enough to know the set; write the prose from the source, not from the figures.

## 2. Copy the harness, then fill the CONTENT block

`assets/build_harness.py` is the content-agnostic harness (fonts, palette, styles, the
helper API, page furniture, build). Copy it to `build_pdf.py` and replace its CONTENT
block. Helpers, in call order, append to `story`:

`P(text, first=False)` body para · `LEAD` lead para · `H1/H2` headings ·
`DISP(text)` centered accent line (formulas/one-liners) · `CO(head, body)` callout ·
`FIG(path, width, cap)` inline figure · `TBL(header, rows, colWidths, bold_cols=(), mono_cols=())`
zebra table · `BULLETS`, `rule`, `SP`, `PB`.

**Expansion is the core job.** For every source section that is a bare list or one thin
line, write 1–3 real paragraphs that say what the list only names — drawn from the
source's own material, never invented. Render enumerable content (taxonomies, threat
classes, metrics, invariants, phases, hypotheses) as `TBL`, and keep a paragraph of prose
around it. Put the one or two sharpest framing statements in a `CO` callout. Aim for the
combination that worked: **prose for the argument, a table for the enumerable, a figure
for the structure.**

## 3. Figures — architecture diagrams, built with `make_figs.py`

Copy `assets/figures_harness.py` to `make_figs.py`. Draw box/arrow/label diagrams that
show the paper's actual structure: tuples/objects, pipelines, planes/stacks, graphs,
comparisons, mappings. One accent title per figure. Save at 200 dpi.

**Always review a contact sheet of all figures before wiring them in**, and fix: tangled
connector lines (draw clean radial/edge ties, not through boxes), boxes running
off-canvas (keep within the 0–10 axis), label overlap (shorten or shrink), and any tofu
glyph. Then rebuild.

## 4. Evidence discipline (non-negotiable)

- If the paper **claims no empirical results**, every figure is architecture/schematic.
  **Never fabricate data charts.** The only quantitative-looking figure allowed is an
  honestly *conceptual* curve; its title must say "conceptual, no measured data" and it
  must carry no numeric ticks.
- Preserve the source's **proposal-vs-result stance** — "proposed," "hypothesis,"
  "would," "is designed to," "not yet demonstrated." Keep a "Note on sources and claims"
  paragraph if the source has one.
- **Never invent** citations, URLs, versions, or dates. Reproduce the source's references
  as given; don't add links the source didn't have.

## 5. Agent co-title rules

The agent credits itself in the byline/author statement and describes honestly what it
did. **At most two co-titles**, chosen by contribution:

- **Co-Editor** — the default whenever the agent is *not* Co-Author: editorial expansion,
  restructuring, formatting, and original figures of the source's *existing* architecture.
- **Co-Author** — claim for authorial prose contribution (writing/expanding substantial
  new prose from the source).
- **Co-Architect** — only if the agent adds *new architectural design content*.
- **Co-Research Engineer** — only if the agent does *external research* and adds
  engineering insights.

Constraint: if either of the two titles is anything **besides Co-Editor**, the other
**must be Co-Author**. Valid sets: `{Co-Editor}`, `{Co-Author}`,
`{Co-Author, Co-Architect}`, `{Co-Author, Co-Research Engineer}`. Never
`{Co-Architect}`, `{Co-Research Engineer}`, or the two paired without Co-Author.
When unsure between Co-Editor and Co-Author, prefer the honest floor (Co-Editor) and offer
the user the elevation. State plainly in the author statement what the agent did and did
not do.

## 6. Glyph & spelling notes (save a rebuild)

- DejaVu **Serif Bold lacks the empty-set glyph** `∅` (U+2205) — it renders as a box in
  `DISP`/bold. Reword ("Execution occurs ⇒ …") or place it in a `mono`/`tblmono` cell
  (DejaVu Sans Mono has it). Greek (Σ Γ Π Ω), arrows (→ ⇒), ≠ ∈ ∧, angle brackets ⟨ ⟩,
  and sub/superscripts render fine. For superscript-zero use ReportLab markup
  `<super>0</super>` (always renders) rather than a raw glyph in bold serif.
- American spelling unless told otherwise: no *behaviour, colour, organis-, analyse,
  optimise, modelled, programme, centre, whilst, towards, grey* in prose.

## 7. Verification checklist (run every build — these are cheap and catch real defects)

1. **Build clean** — script prints `BUILT <path>`, no traceback.
2. **Spelling** — grep the build script prose for British forms; expect none.
3. **Glyphs** — render 1–2 pages with display-math/superscripts at ~150 dpi and look;
   confirm no tofu (especially any `∅`).
4. **Overflow** — render a full contact sheet (`pdftoppm -r 70`) and scan every table and
   figure for overrun rows, split cells, or off-frame images.
5. **Counts** — report page count and approximate word count (`pypdf` extract → `split()`).
6. Fix, rebuild, re-check only what changed.

## 8. Deliver

Copy the PDF to the outputs directory and send it with `SendUserFile` and a one-line
caption. In the report, state (honestly, separating verified from assumed): what expanded,
figures/tables added, the agent's co-title and why, verification results, and the
page/word count. Don't paste a long recap the reader can see in the file.

---
*Companion references built with this pipeline: `Maxey0_SystemOne_intro_paper.pdf`
(29 pp) and `Maxey0_SCW_intro_paper.pdf` (18 pp). The full harness ships in
`assets/build_harness.py` and `assets/figures_harness.py`.*
