# -*- coding: utf-8 -*-
"""
build_harness.py  —  reusable ReportLab harness for the Maxey0 "Execution-Space"
research-paper PDF format (serif body, burnt-sienna accents, callouts, tables,
inline figures, page furniture).

HOW TO USE
  1. Copy this file next to your figures directory.
  2. Fill in the two config blocks (OUTPUT / TITLE-BLOCK) and the CONTENT block.
  3. Build content by calling the helper functions in order: they append to `story`.
  4. `python3 build_harness.py`  ->  writes the PDF and prints the path.

HELPERS (all append to the flowable list `story`, in call order)
  P(text, first=False)   body paragraph; first=True suppresses first-line indent
  LEAD(text)             slightly larger lead paragraph (use once per section start)
  H1(text) / H2(text)    section / subsection headings
  DISP(text)             centered accent "display" line (formulas, one-liners)
  CO(head, body)         callout box (cream, accent left-bar)
  FIG(path, width, cap)  inline figure with centered caption (width in points, e.g. 6.4*inch)
  TBL(header, rows, colWidths, bold_cols=(), mono_cols=())   styled table w/ header + zebra rows
  BULLETS(items)         bullet list
  rule() / SP(h) / PB()  horizontal rule / vertical space / page break

NOTES
  * Math/symbols: DejaVu Serif Bold LACKS the empty-set glyph U+2205 -> reword or
    put it in a mono/`tblmono` cell (DejaVu Sans Mono has it). Greek, arrows,
    <=, >=, !=, in, and, => and sub/superscripts render fine. For superscript-zero
    (e.g. SCW-zero) use the ReportLab markup <super>0</super> which always renders.
  * Keep prose American-spelling; keep the proposal-vs-result stance of the source.
"""
from reportlab.lib.pagesizes import letter
from reportlab.lib.units import inch
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT, TA_JUSTIFY, TA_CENTER
from reportlab.platypus import (BaseDocTemplate, PageTemplate, Frame, Paragraph,
                                Spacer, Table, TableStyle, Image, KeepTogether,
                                PageBreak, HRFlowable)
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from PIL import Image as PILImage

# ---------- CONFIG: OUTPUT ----------
OUTPUT_PDF = "/home/claude/paper.pdf"
FOOT       = "Paper title  ·  short running subtitle"   # left footer on every page

# ---------- fonts ----------
FD = "/usr/share/fonts/truetype/dejavu/"
pdfmetrics.registerFont(TTFont("BodySerif",   FD+"DejaVuSerif.ttf"))
pdfmetrics.registerFont(TTFont("BodySerif-B", FD+"DejaVuSerif-Bold.ttf"))
pdfmetrics.registerFont(TTFont("BodySerif-I", FD+"DejaVuSerif-Italic.ttf"))
pdfmetrics.registerFont(TTFont("HeadSans",    FD+"DejaVuSans.ttf"))
pdfmetrics.registerFont(TTFont("HeadSans-B",  FD+"DejaVuSans-Bold.ttf"))
pdfmetrics.registerFont(TTFont("Mono",        FD+"DejaVuSansMono.ttf"))

# ---------- palette ----------
INK=colors.HexColor("#20242b"); ACC=colors.HexColor("#7c3a12"); ACC2=colors.HexColor("#b5651d")
SLATE=colors.HexColor("#3f5566"); RULE=colors.HexColor("#cdc7bd"); GREY=colors.HexColor("#6f6d68")
LGREY=colors.HexColor("#9a978f"); BOXBG=colors.HexColor("#f4ecdf"); BOXBD=colors.HexColor("#e2d5c0")
BOXBG2=colors.HexColor("#e9eef1"); WHITE=colors.white

def S(n, **k): return ParagraphStyle(n, **k)
title   = S("title", fontName="HeadSans-B", fontSize=19, leading=23, textColor=INK, spaceAfter=6)
subtitle= S("subtitle", fontName="HeadSans", fontSize=11, leading=15, textColor=ACC, spaceAfter=2)
byline  = S("byline", fontName="HeadSans", fontSize=8.6, leading=12.2, textColor=GREY, spaceAfter=2)
h1      = S("h1", fontName="HeadSans-B", fontSize=13, leading=16, textColor=INK, spaceBefore=15, spaceAfter=6)
h2      = S("h2", fontName="HeadSans-B", fontSize=10.6, leading=13, textColor=ACC, spaceBefore=11, spaceAfter=4)
body    = S("body", fontName="BodySerif", fontSize=9.6, leading=14.2, textColor=INK, alignment=TA_JUSTIFY, spaceAfter=7)
body1   = S("body1", parent=body, firstLineIndent=0)
lead    = S("lead", fontName="BodySerif", fontSize=10.4, leading=15.4, textColor=INK, alignment=TA_JUSTIFY, spaceAfter=8)
cap     = S("cap", fontName="HeadSans", fontSize=7.6, leading=10, textColor=GREY, alignment=TA_CENTER, spaceBefore=3, spaceAfter=11)
disp    = S("disp", fontName="BodySerif-B", fontSize=10.4, leading=14, textColor=ACC, alignment=TA_CENTER, spaceBefore=3, spaceAfter=7)
mono    = S("mono", fontName="Mono", fontSize=8.2, leading=11.4, textColor=INK, alignment=TA_LEFT, spaceAfter=6, leftIndent=8)
bullet  = S("bullet", fontName="BodySerif", fontSize=9.5, leading=13.6, textColor=INK, alignment=TA_LEFT, leftIndent=8, spaceAfter=2)
boxhead = S("boxhead", fontName="HeadSans-B", fontSize=9, leading=12, textColor=ACC, spaceAfter=3)
boxbody = S("boxbody", fontName="BodySerif", fontSize=8.8, leading=12.6, textColor=INK, alignment=TA_JUSTIFY, spaceAfter=4)
tblcell = S("tblcell", fontName="BodySerif", fontSize=8.1, leading=10.6, textColor=INK)
tblcellb= S("tblcellb", fontName="BodySerif-B", fontSize=8.1, leading=10.6, textColor=INK)
tblhead = S("tblhead", fontName="HeadSans-B", fontSize=8.2, leading=10.8, textColor=WHITE)
tblmono = S("tblmono", fontName="Mono", fontSize=7.7, leading=10.4, textColor=INK)
refst   = S("ref", fontName="BodySerif", fontSize=8.1, leading=11.6, textColor=INK, leftIndent=15, firstLineIndent=-15, spaceAfter=3)
toc     = S("toc", fontName="BodySerif", fontSize=9.2, leading=15, textColor=INK)

story=[]
def P(t, first=False): story.append(Paragraph(t, body1 if first else body))
def LEAD(t): story.append(Paragraph(t, lead))
def H1(t): story.append(Paragraph(t, h1))
def H2(t): story.append(Paragraph(t, h2))
def DISP(t): story.append(Paragraph(t, disp))
def SP(h=4): story.append(Spacer(1, h))
def PB(): story.append(PageBreak())
def rule(c=RULE, w=0.8, sb=2, sa=6): story.append(HRFlowable(width="100%", thickness=w, color=c, spaceBefore=sb, spaceAfter=sa))
def BULLETS(items):
    for it in items: story.append(Paragraph("•&nbsp;&nbsp;"+it, bullet))
    SP(4)
def CO(head, bodytext):
    inner=[Paragraph(head, boxhead), Paragraph(bodytext, boxbody)]
    t=Table([[inner]], colWidths=[6.5*inch])
    t.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,-1),BOXBG),("BOX",(0,0),(-1,-1),0.8,BOXBD),
        ("LEFTPADDING",(0,0),(-1,-1),10),("RIGHTPADDING",(0,0),(-1,-1),10),
        ("TOPPADDING",(0,0),(-1,-1),7),("BOTTOMPADDING",(0,0),(-1,-1),7),("LINEBEFORE",(0,0),(0,-1),3,ACC)]))
    story.append(t)
def FIG(path, width, caption):
    iw,ih=PILImage.open(path).size; h=width*ih/iw
    story.append(KeepTogether([Image(path, width=width, height=h), Paragraph(caption, cap)]))
def TBL(header, rows, colWidths, headbg=ACC, mono_cols=(), bold_cols=()):
    def mk(txt,ci):
        st=tblmono if ci in mono_cols else (tblcellb if ci in bold_cols else tblcell)
        return Paragraph(txt, st)
    data=[[Paragraph(h, tblhead) for h in header]]
    for r in rows: data.append([mk(c,ci) for ci,c in enumerate(r)])
    t=Table(data, colWidths=colWidths, repeatRows=1)
    t.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),headbg),
        ("ROWBACKGROUNDS",(0,1),(-1,-1),[WHITE,BOXBG]),("LINEBELOW",(0,0),(-1,-1),0.4,RULE),
        ("VALIGN",(0,0),(-1,-1),"MIDDLE"),("TOPPADDING",(0,0),(-1,-1),3.4),("BOTTOMPADDING",(0,0),(-1,-1),3.4),
        ("LEFTPADDING",(0,0),(-1,-1),6),("RIGHTPADDING",(0,0),(-1,-1),6)]))
    story.append(KeepTogether([t]) if len(rows)<=6 else t); SP(7)

# ============================ CONTENT ============================
# ---- TITLE BLOCK (edit) ----
story.append(Paragraph("Paper Title", title))
story.append(Paragraph("One-line subtitle in accent color", subtitle))
SP(4); rule(ACC,1.2,2,4)
story.append(Paragraph("By Author One and Author Two &nbsp;·&nbsp; Organization", byline))
story.append(Paragraph("contact@example.com &nbsp;·&nbsp; Month Year &nbsp;·&nbsp; Co-Editor: Agent &nbsp;·&nbsp; introductory research paper", byline))
rule(RULE,0.8,4,8)

H2("Abstract")
P("Abstract text ...", first=True)

# ---- Contents (optional) ----
H2("Contents")
for t in ["1&nbsp;&nbsp;Introduction", "2&nbsp;&nbsp;..."]:
    story.append(Paragraph(t, toc))
rule(RULE,0.8,8,2); PB()

# ---- Sections: expand every listed/thin source section into prose. Use TBL for
#      enumerable content (taxonomies, threat classes, metrics, invariants, phases),
#      FIG for architecture diagrams, CO for the one or two key framing statements. ----
H1("1&nbsp;&nbsp;Introduction")
LEAD("Lead paragraph ...")
P("Body ...", first=True)
# FIG("fig/fig1.png", 6.4*inch, "Figure 1. caption.")
# TBL(["Col A","Col B"], [["a","b"]], [1.5*inch, 5.0*inch], bold_cols=(0,))

# ============================ BUILD ============================
def on_page(canvas, doc):
    canvas.saveState()
    canvas.setFont("HeadSans", 7); canvas.setFillColor(LGREY)
    canvas.drawString(0.9*inch, 0.55*inch, FOOT)
    canvas.drawRightString(7.6*inch, 0.55*inch, str(doc.page))
    canvas.setStrokeColor(RULE); canvas.setLineWidth(0.5)
    canvas.line(0.9*inch, 0.72*inch, 7.6*inch, 0.72*inch)
    canvas.restoreState()

doc=BaseDocTemplate(OUTPUT_PDF, pagesize=letter,
                    leftMargin=0.9*inch, rightMargin=0.9*inch, topMargin=0.85*inch, bottomMargin=0.85*inch,
                    title="Paper Title", author="Authors; Co-Editor Agent")
doc.addPageTemplates([PageTemplate(id="all",
    frames=[Frame(doc.leftMargin, doc.bottomMargin, doc.width, doc.height, id="main")], onPage=on_page)])
doc.build(story)
print("BUILT", OUTPUT_PDF)
