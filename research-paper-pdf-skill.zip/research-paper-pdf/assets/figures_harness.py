#!/usr/bin/env python3
"""
figures_harness.py  —  matplotlib helpers for inline architecture figures that
match the PDF harness palette (burnt-sienna accent, cream/slate fills).

EVIDENCE RULE (do not violate)
  If the source paper claims NO empirical results, every figure must be an
  ARCHITECTURE / SCHEMATIC diagram (boxes, arrows, tuples, planes, graphs).
  Do NOT plot measured-looking data. The only quantitative-looking figure allowed
  is a clearly-conceptual curve, and its title MUST say "conceptual, no measured
  data" and it MUST have no numeric tick labels.

CONVENTIONS
  * Draw with box()/arrow()/label() on a 10-wide axis via newfig(w, h); axis off.
  * Save at 200 dpi with save(fig, name) -> writes /home/claude/fig/<name>.png
  * Keep one clear accent title per figure (color=ACC, weight="bold").
  * Review a contact sheet of all figures before wiring them into the PDF; fix
    overlaps, off-canvas boxes, and tofu glyphs, then rebuild.
"""
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Circle
import numpy as np, os

OUTDIR = "/home/claude/fig"
os.makedirs(OUTDIR, exist_ok=True)
ACC="#7c3a12"; ACC2="#b5651d"; INK="#20242b"; SLATE="#3f5566"; GREEN="#4a6a4d"
GREY="#7c7a75"; LGREY="#c9c6c0"; BG="#ffffff"; BOXBG="#f1e9df"; BOXBG2="#e7edf0"; BLOCK="#fbf7f1"; RED="#a23b2e"
plt.rcParams.update({"font.family":"DejaVu Sans","font.size":10.5,"text.color":INK,"figure.dpi":200,"savefig.dpi":200})

def box(ax,x,y,w,h,t,fc=BLOCK,ec=ACC,tc=INK,fs=10.5,lw=1.4,weight="normal",r=0.02,ha="center"):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle=f"round,pad=0.012,rounding_size={r}",
        linewidth=lw,edgecolor=ec,facecolor=fc,mutation_aspect=1))
    ax.text(x+(w/2 if ha=="center" else 0.06),y+h/2,t,ha=ha,va="center",fontsize=fs,color=tc,weight=weight,zorder=5)
def arrow(ax,x1,y1,x2,y2,color=ACC,lw=1.6,style="-|>",ls="-",rad=0.0,mut=13):
    ax.add_patch(FancyArrowPatch((x1,y1),(x2,y2),arrowstyle=style,mutation_scale=mut,
        linewidth=lw,color=color,linestyle=ls,connectionstyle=f"arc3,rad={rad}",zorder=4))
def label(ax,x,y,t,fs=8.6,color=GREY,ha="center",va="center",weight="normal",style="normal",rot=0):
    ax.text(x,y,t,fontsize=fs,color=color,ha=ha,va=va,weight=weight,style=style,rotation=rot,zorder=6)
def newfig(w,h):
    fig,ax=plt.subplots(figsize=(w,h)); ax.set_xlim(0,10); ax.set_ylim(0,10*h/w); ax.axis("off"); return fig,ax
def save(fig,name):
    fig.savefig(f"{OUTDIR}/{name}.png",bbox_inches="tight",pad_inches=0.06,facecolor=BG); plt.close(fig)

# ---- EXAMPLE 1: a labeled tuple/object row ----
def example_tuple():
    fig,ax=newfig(9.2,3.6); H=ax.get_ylim()[1]
    box(ax,3.1,H-1.5,3.8,1.0,"OBJ = ( A, B, C, D )",fc=BOXBG,ec=ACC,lw=1.8,fs=13,weight="bold")
    for i,(sym,desc) in enumerate([("A","first"),("B","second"),("C","third"),("D","fourth")]):
        x=1.0+i*2.0
        box(ax,x,0.6,1.3,0.95,sym,fc=BLOCK,ec=SLATE,lw=1.2,fs=12,weight="bold",tc=SLATE)
        label(ax,x+0.65,0.35,desc,fs=7,color=GREY)
    label(ax,5.0,H-0.3,"Accent title describing the object",fs=9.4,color=ACC,weight="bold")
    save(fig,"example_tuple")

# ---- EXAMPLE 2: a pipeline of stages ----
def example_pipeline():
    fig,ax=newfig(9.2,2.4); H=ax.get_ylim()[1]
    stages=["Stage 1","Stage 2","Stage 3","Stage 4"]; n=len(stages); w=1.7; gap=(10-0.4-n*w)/(n-1); x0=0.2; y=H-1.5
    xs=[]
    for i,t in enumerate(stages):
        x=x0+i*(w+gap); box(ax,x,y,w,1.0,t,fc=BOXBG,ec=ACC,fs=9.5,weight="bold"); xs.append((x,x+w))
    for i in range(n-1): arrow(ax,xs[i][1]+0.03,y+0.5,xs[i+1][0]-0.03,y+0.5,lw=1.8)
    label(ax,5.0,H-0.3,"A -> B -> C -> D",fs=10,color=ACC,weight="bold")
    save(fig,"example_pipeline")

# ---- EXAMPLE 3: a CONCEPTUAL curve (only if honestly conceptual) ----
def example_conceptual_curve():
    fig,ax=plt.subplots(figsize=(7.0,4.0))
    x=np.linspace(0,10,400); y=1/(1+np.exp((x-5)*0.8)); y=(y-y.min())/(y.max()-y.min())
    ax.plot(x,y,color=ACC,lw=2.6)
    ax.set_xlabel("X axis (illustrative)",fontsize=9.5,color=INK); ax.set_ylabel("Y axis (illustrative)",fontsize=9.5,color=INK)
    ax.set_title("What the curve argues  ·  conceptual, no measured data",fontsize=9.4,color=ACC,weight="bold",pad=10)
    ax.set_xticks([]); ax.set_yticks([])
    for s in ["top","right"]: ax.spines[s].set_visible(False)
    ax.spines["left"].set_color(GREY); ax.spines["bottom"].set_color(GREY)
    fig.savefig(f"{OUTDIR}/example_curve.png",bbox_inches="tight",pad_inches=0.08,facecolor=BG); plt.close(fig)

if __name__ == "__main__":
    example_tuple(); example_pipeline(); example_conceptual_curve()
    print("wrote example figures to", OUTDIR)
