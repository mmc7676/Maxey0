# research-paper-pdf — assets

Two ready-to-run templates for the Maxey0 "Execution-Space" research-paper PDF pipeline.
`SKILL.md` (one level up) is the full operating guide; this README is the quickstart.

## Files
- **build_harness.py** — the ReportLab harness (fonts, palette, styles, helper API,
  page furniture, build). Copy to `build_pdf.py`, fill the CONTENT block, run.
- **figures_harness.py** — matplotlib helpers + example figures. Copy to `make_figs.py`,
  write your architecture diagrams, run. Writes PNGs to `/home/claude/fig`.

## Requirements
Python 3 with `reportlab`, `matplotlib`, `Pillow`, `pypdf`, and the DejaVu TrueType fonts
at `/usr/share/fonts/truetype/dejavu/` (Serif, Serif-Bold, Serif-Italic, Sans, Sans-Bold,
Sans Mono). `pdftoppm` (poppler-utils) is used for verification renders.

## Quickstart
```bash
python3 make_figs.py     # -> fig/*.png   (review a contact sheet, fix, rerun)
python3 build_pdf.py     # -> the PDF     (prints BUILT <path>)
```

## The five rules that keep output correct
1. Expand every thin/listed source section into real prose; tables for enumerable content.
2. Architecture figures only — if the paper claims no results, never plot data
   (one clearly-"conceptual, no measured data" curve is the sole exception).
3. Preserve the source's proposal-vs-result stance; never invent citations or URLs.
4. Agent co-titles: at most two; Co-Editor by default; any non-Co-Editor title must be
   paired with Co-Author (see SKILL.md §5).
5. Verify before delivery: build clean, spelling grep, glyph render, overflow contact
   sheet, page/word count. Note: DejaVu Serif Bold lacks `∅` — reword or use a mono cell.
```
