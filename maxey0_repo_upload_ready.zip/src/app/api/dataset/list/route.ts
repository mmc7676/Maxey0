import { NextResponse } from "next/server";
import { db } from "@/server/db";

export async function GET() {
  const rows = db().prepare("SELECT id, name, created_at FROM datasets ORDER BY created_at DESC LIMIT 200").all() as any[];
  return NextResponse.json({ datasets: rows.map(r => ({ id: r.id, name: r.name, createdAt: new Date(r.created_at).toISOString() })) });
}
