import { Card } from "@/lib/ui/Card";

export default function Page() {
  return (
    <div className="space-y-4">
      <div className="text-2xl font-semibold tracking-tight">Latent Space Lab</div>
      <div className="text-sm text-white/70">
        Snapshot-first latent observability with a user-defined 64-axis constitution. Generate datasets, compute Voronoi partitions,
        visualize the Delaunay dual, and replay snapshot sequences with KV-cached measurements.
      </div>

      <div className="grid grid-cols-2 gap-4">
        <Card title="Core primitives">
          <ul className="list-disc pl-5 space-y-1">
            <li>64-axis constitution → deterministic axis embedding</li>
            <li>Snapshot series (pre/post) → Δ vectors + drift metrics</li>
            <li>Voronoi partitions (k-means centroids) → cell IDs</li>
            <li>Dual graph (Delaunay in 2D, adjacency approximation in high-D)</li>
            <li>KV cache for expensive computations keyed by config hash</li>
          </ul>
        </Card>

        <Card title="Quickstart">
          <ol className="list-decimal pl-5 space-y-1">
            <li>Constitution: edit weights/keywords.</li>
            <li>Datasets: generate a dataset.</li>
            <li>Latent Map: compute a projection.</li>
            <li>Voronoi ⇄ Delaunay: compute partitions and inspect adjacency.</li>
            <li>Snapshots: record a step sequence and inspect drift/churn.</li>
            <li>SCW Seeds: export starting vectors.</li>
          </ol>
        </Card>
      </div>
    </div>
  );
}
