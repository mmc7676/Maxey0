"use client";

import { useEffect, useMemo, useState } from "react";
import { Card } from "@/lib/ui/Card";
import { Button } from "@/lib/ui/Button";
import { Input } from "@/lib/ui/Input";
import { Select } from "@/lib/ui/Select";
import { ScatterChart, Scatter, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";

type DatasetRow = { id: string; name: string; createdAt: string };

export default function MapperPage() {
  const [datasets, setDatasets] = useState<DatasetRow[]>([]);
  const [datasetId, setDatasetId] = useState<string>("");
  const [method, setMethod] = useState<"pca" | "umap">("pca");
  const [seed, setSeed] = useState("maxey0-proj");
  const [busy, setBusy] = useState(false);
  const [points, setPoints] = useState<{ id: string; label: string; x: number; y: number }[]>([]);
  const [model, setModel] = useState<any>(null);

  async function refreshDatasets() {
    const r = await fetch("/api/dataset/list");
    const j = await r.json();
    const ds = j.datasets ?? [];
    setDatasets(ds);
    if (!datasetId && ds.length) setDatasetId(ds[0].id);
  }

  useEffect(() => { refreshDatasets(); }, []);

  async function compute() {
    if (!datasetId) return;
    setBusy(true);
    try {
      const r = await fetch("/api/projection/compute", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ datasetId, method, seed, umap: { nNeighbors: 15, minDist: 0.1, spread: 1.0 } }),
      });
      const j = await r.json();
      setPoints(j.points ?? []);
      setModel(j.model ?? null);
    } finally {
      setBusy(false);
    }
  }

  const data = useMemo(() => points.map(p => ({ ...p })), [points]);

  return (
    <div className="space-y-4">
      <div className="text-2xl font-semibold tracking-tight">Latent Map</div>

      <div className="grid grid-cols-3 gap-4">
        <Card title="Projection">
          <div className="space-y-2">
            <div className="text-xs text-white/60">Dataset</div>
            <Select value={datasetId} onChange={(e) => setDatasetId(e.target.value)}>
              {datasets.map(d => <option key={d.id} value={d.id}>{d.name} · {d.id}</option>)}
            </Select>
            <div className="text-xs text-white/60">Method</div>
            <Select value={method} onChange={(e) => setMethod(e.target.value as any)}>
              <option value="pca">PCA (fast, linear)</option>
              <option value="umap">UMAP (nonlinear neighborhoods)</option>
            </Select>
            <div className="text-xs text-white/60">Seed</div>
            <Input value={seed} onChange={(e) => setSeed(e.target.value)} />
            <Button onClick={compute} disabled={busy}>{busy ? "Computing…" : "Compute projection"}</Button>
            {model ? (
              <div className="mt-2 text-xs text-white/60">Model: <b>{model.method}</b></div>
            ) : null}
          </div>
        </Card>

        <Card title="Interpretation">
          <div className="space-y-2 text-sm">
            This view is a <b>2D projection</b> of your 64D constitution-axis space. It is intended for inspection,
            adjacency visualization, and time-sequence replay—not as a claim about the true manifold.
          </div>
        </Card>

        <Card title="Next step">
          <div className="space-y-2 text-sm">
            Use <b>Voronoi ⇄ Delaunay</b> to compute partitions and inspect the dual graph. Use <b>Snapshots</b> to record and
            quantify drift.
          </div>
        </Card>
      </div>

      <Card title="Scatter (projection space)">
        <div className="h-[520px]">
          <ResponsiveContainer width="100%" height="100%">
            <ScatterChart>
              <XAxis dataKey="x" type="number" name="x" tick={{ fill: "#cbd5e1" }} />
              <YAxis dataKey="y" type="number" name="y" tick={{ fill: "#cbd5e1" }} />
              <Tooltip cursor={{ strokeDasharray: "3 3" }} contentStyle={{ background: "#0b1020", border: "1px solid rgba(255,255,255,0.1)" }} />
              <Scatter data={data} />
            </ScatterChart>
          </ResponsiveContainer>
        </div>
      </Card>
    </div>
  );
}
