# Maxey0 Latent Space Lab (full-stack Next.js)

Local-first latent-space observability lab:
- 64-axis constitution (editable weights + keywords)
- dataset generation + JSONL export
- PCA/UMAP projection
- Voronoi partitions + Delaunay dual (2D exact) and high-D dual approximation
- snapshot series with Δ metrics
- KV cache for expensive measurements
- SCW seed vector export
- experiments: anchor-based trilateration + fold/unfold reconstruction loss

## Quickstart
```bash
npm install
npm run dev
# http://localhost:3000
```

Reset DB:
```bash
npm run db:reset
```

## Persistence
- SQLite: `./data/latentlab.sqlite`
- Default constitution: `./data/constitution.default.json`

## Note on 64 laws
The provided source list contains 62 laws; this repo appends two additional editable laws to reach 64.

## Docs
- Theory notes: `./docs/latent_space_theory.md`
- Reference inputs: `./docs/reference/`

## Demo dataset
Seed a demo dataset into the local SQLite DB:
```bash
npm run demo:seed
```
Then open **Datasets** in the UI and select `demo`.
