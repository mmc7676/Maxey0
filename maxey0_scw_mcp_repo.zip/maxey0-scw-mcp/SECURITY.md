# Security Policy

## Reporting a Vulnerability
If you discover a security vulnerability, do not open a public issue. Instead, contact the maintainer privately.

## Scope
This repository implements an MCP server that can execute sandboxed commands. Treat it as security-sensitive:
- Use allowlists for tool/capability exposure.
- Prefer network-disabled sandboxes (default in this repo).
- Do not run untrusted code without sandboxing.
