# Maxey0 — Parent Routing Spec (Copilot Studio)

## Goal
Route every user utterance to exactly one child copilot (Maxey1–Maxey9) and then to the most specific Topic Node, using deterministic rules and minimal disambiguation.

## Child Copilots
- Maxey1: Copilot-Knowledge-Grounding
- Maxey2: Copilot-Data-Dataverse
- Maxey3: Copilot-Actions-Automation
- Maxey4: Copilot-API-Integrations
- Maxey5: Copilot-Channels-UX-Deploy
- Maxey6: Copilot-Quality-Analytics
- Maxey7: Copilot-AdminOps
- Maxey8: Copilot-Security-Compliance
- Maxey9: Copilot-ALM-ReleaseOps

## Parent Topic: “Route Request”
### Variables
- user_intent_raw (string) — the user’s last message
- route_child (string) — one of Maxey1..Maxey9
- route_topic_node (string) — a topic_node from the routing table
- route_confidence (number 0–1)
- needs_disambiguation (boolean)

### Node Graph (Classic Topics)
1) **Message**: “Got it. I’ll route this to the right specialist.”
2) **Set variable**: user_intent_raw = {System.Activity.Text}
3) **Action (internal classification)**: “ClassifyRouting”
   - Inputs: user_intent_raw
   - Outputs: candidate_children[] with scores, candidate_topics[] with scores
4) **Condition**: If top_score < threshold OR tie between top-2 within epsilon → needs_disambiguation = true
5) If needs_disambiguation = true:
   - **Question**: ask one disambiguation question (see rules below)
   - **Action**: re-run ClassifyRouting using the answer appended to user_intent_raw
6) **Set variables**:
   - route_child = top_child
   - route_topic_node = top_topic_node within that child
7) **Call child copilot** (handoff/delegation):
   - Provide: user_intent_raw, route_topic_node, any collected identifiers
8) **Return**: the child copilot’s final answer to the user

## Priority Rules (deterministic)
When multiple children match, break ties by precedence:
1) Maxey8 (Security/Compliance)
2) Maxey9 (ALM/ReleaseOps)
3) Maxey7 (AdminOps)
4) Maxey2 (Data/Dataverse)
5) Maxey3 (Actions/Automation)
6) Maxey4 (API/Integrations)
7) Maxey1 (Knowledge/Grounding)
8) Maxey5 (Channels/UX/Deploy)
9) Maxey6 (Quality/Analytics)

When multiple Topic Nodes match within the same child:
- Prefer the Topic Node whose trigger phrase is the **longest exact match** (string length).
- If still tied: prefer the Topic Node with **more specific required_variables** (more required fields).
- If still tied: stable sort by topic_node name (A→Z).

## Disambiguation Question Patterns
Ask **one** question, chosen by the top 2 candidates:
- If Security is in top-2: “Is this about security/compliance (DLP, auth, access control, privacy/PII, residency), or something else?”
- If ALM is in top-2: “Is this about release/ALM (solutions, versioning, import/export, pipelines, rollback), or something else?”
- Otherwise: “Which area is this: Knowledge, Data, Actions, Integrations, Channels, Quality, Admin, Security, or ALM?”

## Required Behavior
- Do not call any child toolset before routing is finalized.
- Pass only minimal context to children (least privilege).
- If a child reports “blocked by permission/policy,” follow the escalation path below.
