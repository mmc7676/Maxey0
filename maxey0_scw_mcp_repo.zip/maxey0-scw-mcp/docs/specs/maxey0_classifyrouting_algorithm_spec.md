# ClassifyRouting — Normative Algorithm Specification (v1)

This document defines REQUIRED behavior for the `ClassifyRouting` Custom Action used by **Maxey0** (parent) to route requests to **Maxey1–Maxey9** (child copilots) and a specific `topic_node`.

## Inputs
- `user_intent_raw` (string)
- `routing_table_version` (string)
- Optional `conversation_context` fields

## Routing Table Requirements
The action MUST load the routing table identified by `routing_table_version`. Each row MUST include:
- `topic_node` (string, unique)
- `route_to` (child name: Maxey1..Maxey9)
- `trigger_phrases` (semicolon-separated phrases)
- `required_variables` (semicolon-separated list)

## Precedence Order (Child tie-break)
When candidate children are tied, precedence MUST be applied in this exact order:
1. Maxey8
2. Maxey9
3. Maxey7
4. Maxey2
5. Maxey3
6. Maxey4
7. Maxey1
8. Maxey5
9. Maxey6

## Scoring
The action MUST compute a topic score for each topic row based on phrase matching.

### Phrase Matching (per topic)
Let `U` be the normalized user utterance:
- Lowercase
- Collapse whitespace
- Remove punctuation except alphanumerics and spaces

Let each trigger phrase `p` be normalized the same way.

Match types:
- `exact_phrase`: `U == p`
- `contains_phrase`: `p` is a substring of `U`
- `keyword_overlap`: token overlap above 0 (see below)

Base match score:
- exact_phrase = 1.00
- contains_phrase = 0.80
- keyword_overlap = 0.60 * Jaccard(tokens(U), tokens(p))

Length bonus:
- Add `0.01 * min(len(p), 60)` to the base score (cap phrase length at 60 chars for bonus).

Topic score:
- The topic score is the maximum score over all phrases for that topic.

### Candidate Topic Selection
The action MUST return:
- Top `max_candidate_topics` topics by score across the entire table.

### Candidate Child Scoring
For each child, compute:
- child_score = max(topic_score) among that child’s topics.

Return top `max_candidate_children` children by child_score.

## Selection & Tie-breaking
### Top Child
Select the child with the highest `child_score`.
If two children have scores within `tie_epsilon`, apply **precedence order**.

### Top Topic Node
Within the selected child:
1) Select the topic with the highest topic_score.
2) If tied within `tie_epsilon`:
   - Prefer the topic whose matched_phrase has the **longest normalized string length**.
3) If still tied:
   - Prefer the topic with **more required_variables** (count).
4) If still tied:
   - Prefer A→Z by `topic_node`.

## Disambiguation
Set `needs_disambiguation=true` if:
- `top_score < confidence_threshold`, OR
- top-2 child scores are within `tie_epsilon`, OR
- top-2 topic scores (within selected child) are within `tie_epsilon`

When `needs_disambiguation=true`, the action MUST provide a `disambiguation_question`:
- If Maxey8 is in the top-2 children: ask the security/compliance disambiguation.
- Else if Maxey9 is in the top-2 children: ask the ALM disambiguation.
- Else ask the generic “Which area…” disambiguation.

## Output Requirements
The response MUST include:
- `candidate_children[]` with scores and evidence (matched keywords + phrases)
- `candidate_topics[]` with matched_phrase and match_type
- `explainability` containing precedence order and thresholds used
