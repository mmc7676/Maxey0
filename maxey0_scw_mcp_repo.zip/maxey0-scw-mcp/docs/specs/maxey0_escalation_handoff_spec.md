# Maxey0 — Escalation & Handoff Path

## When to escalate
Escalate when any child copilot returns one of:
- Permission denied / insufficient privileges
- DLP/policy blocked connector or action
- Compliance restriction / residency restriction
- Cannot access knowledge source due to security trimming
- ALM operation blocked by environment rules
- Tool timeout after bounded retries

## Escalation Topic: “Human Handoff / Admin Required”
### Inputs
- failing_child (Maxey1..Maxey9)
- route_topic_node
- minimal_error_text (verbatim)
- environment (if known)
- connector/action name (if relevant)

### Node Graph (Classic Topics)
1) **Message**: “This requires admin/policy intervention. I can guide the exact fix steps.”
2) **Question**: “Paste the exact error text and tell me which environment/channel you’re in.”
3) **Condition**:
   - If security/policy keywords → route to Maxey8
   - If ALM/deployment keywords → route to Maxey9
   - Else admin ops → route to Maxey7
4) **Child call**: specialized child returns click-path steps + success checks + fallback.
5) **Message**: “If you can’t change this due to sandbox limits, use the fallback path.”

## Data Minimization
- Never include secrets/tokens in escalation payloads.
- Redact PII before sending context across copilots.
