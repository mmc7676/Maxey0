# maxey0-scw-mcp

**What this is:** a production-grade **MCP server** that exposes two core “Maxey0 primitives”:

1) **Deterministic routing** (`maxey0.route.classify`) implementing your `ClassifyRouting` normative spec.  
2) **SCW execution capsules** (`maxey0.scw.*`) with **sandboxed execution**, **tick logs**, and **evidence digests**.

Designed to run:
- **Locally via STDIO** for Claude Desktop / MCPB bundles (do not write to stdout; log to stderr).
- **As a Streamable HTTP MCP server** for testing and non-Desktop clients.

## Quickstart

```bash
uv sync --all-extras --dev
make test
make run-http   # http://localhost:8787/mcp
```

## Claude Desktop config (manual)

```json
{
  "mcpServers": {
    "maxey0-scw": {
      "command": "uv",
      "args": ["run", "python", "-m", "maxey0_scw_mcp", "--transport", "stdio"]
    }
  }
}
```

## MCPB bundle

See `mcpb/manifest.uv.json` and `scripts/build_mcpb.sh`.

```bash
npm i -g @anthropic-ai/mcpb
make mcpb-pack
# dist/maxey0-scw.mcpb
```
