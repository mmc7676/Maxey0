from __future__ import annotations

import csv
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class RoutingRow:
    topic_node: str
    route_to: str
    trigger_phrases: list[str]
    required_variables: list[str]
    disambiguation_question: str | None


def load_routing_table_csv(path: str) -> list[RoutingRow]:
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"Routing table not found: {p}")
    rows: list[RoutingRow] = []
    with p.open("r", encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f)
        for r in reader:
            topic_node = (r.get("topic_node") or "").strip()
            route_to = (r.get("route_to") or "").strip()
            trigger_phrases_raw = (r.get("trigger_phrases") or "").strip()
            required_vars_raw = (r.get("required_variables") or "").strip()
            disambig = (r.get("disambiguation_question") or "").strip() or None

            if not topic_node or not route_to:
                continue

            trigger_phrases = [p.strip() for p in trigger_phrases_raw.split(";") if p.strip()]
            required_variables = [v.strip() for v in required_vars_raw.split(";") if v.strip()]
            rows.append(
                RoutingRow(
                    topic_node=topic_node,
                    route_to=route_to,
                    trigger_phrases=trigger_phrases,
                    required_variables=required_variables,
                    disambiguation_question=disambig,
                )
            )
    if not rows:
        raise ValueError(f"Routing table empty: {p}")
    return rows
