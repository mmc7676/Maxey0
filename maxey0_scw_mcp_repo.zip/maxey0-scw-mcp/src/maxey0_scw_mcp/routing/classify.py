from __future__ import annotations

from dataclasses import dataclass

from maxey0_scw_mcp.routing.models import (
    CandidateChild,
    CandidateChildEvidence,
    CandidateTopic,
    ClassifyRoutingRequest,
    ClassifyRoutingResponse,
    Explainability,
)
from maxey0_scw_mcp.routing.normalize import normalize_text, tokens
from maxey0_scw_mcp.routing.table import RoutingRow, load_routing_table_csv


_PRECEDENCE: list[str] = ["Maxey8", "Maxey9", "Maxey7", "Maxey2", "Maxey3", "Maxey4", "Maxey1", "Maxey5", "Maxey6"]


def _jaccard(a: set[str], b: set[str]) -> float:
    if not a and not b:
        return 0.0
    inter = len(a & b)
    union = len(a | b)
    return inter / union if union else 0.0


@dataclass(frozen=True)
class PhraseMatch:
    phrase: str
    match_type: str
    score: float


def _phrase_best_match(user_norm: str, phrase: str) -> PhraseMatch:
    p_norm = normalize_text(phrase)
    if not p_norm:
        return PhraseMatch(phrase=phrase, match_type="keyword_overlap", score=0.0)

    if user_norm == p_norm:
        base = 1.00
        match_type = "exact_phrase"
    elif p_norm in user_norm:
        base = 0.80
        match_type = "contains_phrase"
    else:
        base = 0.60 * _jaccard(tokens(user_norm), tokens(p_norm))
        match_type = "keyword_overlap"

    length_bonus = 0.01 * min(len(p_norm), 60)
    return PhraseMatch(phrase=phrase, match_type=match_type, score=min(1.0, base + length_bonus))


@dataclass(frozen=True)
class TopicScore:
    row: RoutingRow
    score: float
    matched_phrase: str
    match_type: str


class ClassifyRoutingEngine:
    def __init__(self, *, routing_table_version: str, rows: list[RoutingRow]):
        self.routing_table_version = routing_table_version
        self.rows = rows

    @classmethod
    def from_csv(cls, path: str, *, routing_table_version: str = "v1") -> "ClassifyRoutingEngine":
        return cls(routing_table_version=routing_table_version, rows=load_routing_table_csv(path))

    def _score_topics(self, user_intent_raw: str) -> list[TopicScore]:
        u_norm = normalize_text(user_intent_raw)
        scored: list[TopicScore] = []
        for row in self.rows:
            best = PhraseMatch(phrase="", match_type="keyword_overlap", score=0.0)
            for phrase in row.trigger_phrases:
                pm = _phrase_best_match(u_norm, phrase)
                if pm.score > best.score:
                    best = pm
            scored.append(TopicScore(row=row, score=best.score, matched_phrase=best.phrase, match_type=best.match_type))
        scored.sort(key=lambda t: t.score, reverse=True)
        return scored

    def classify(self, request: ClassifyRoutingRequest) -> ClassifyRoutingResponse:
        max_candidate_children = request.options.max_candidate_children if request.options else 5
        max_candidate_topics = request.options.max_candidate_topics if request.options else 10
        confidence_threshold = request.options.confidence_threshold if request.options else 0.55
        tie_epsilon = request.options.tie_epsilon if request.options else 0.05

        topic_scores = self._score_topics(request.user_intent_raw)
        top_topics = topic_scores[:max_candidate_topics]

        child_best: dict[str, TopicScore] = {}
        for ts in top_topics:
            c = ts.row.route_to
            prev = child_best.get(c)
            if prev is None or ts.score > prev.score:
                child_best[c] = ts

        def child_sort_key(item: tuple[str, TopicScore]) -> tuple[float, int, str]:
            child, ts = item
            precedence = _PRECEDENCE.index(child) if child in _PRECEDENCE else len(_PRECEDENCE)
            return (ts.score, -precedence, child)

        candidates_sorted = sorted(child_best.items(), key=child_sort_key, reverse=True)[:max_candidate_children]

        tie_breakers_applied: list[str] = []
        if not candidates_sorted:
            top_child = "Maxey1"
            top_topic = topic_scores[0].row.topic_node if topic_scores else "unknown"
            top_score = 0.0
        else:
            top_child = candidates_sorted[0][0]
            top_score = candidates_sorted[0][1].score

            if len(candidates_sorted) > 1 and abs(candidates_sorted[0][1].score - candidates_sorted[1][1].score) <= tie_epsilon:
                tie_breakers_applied.append("child_precedence_order")
                tied = [c for c, ts in candidates_sorted if abs(ts.score - top_score) <= tie_epsilon]
                tied.sort(key=lambda c: _PRECEDENCE.index(c) if c in _PRECEDENCE else 9999)
                top_child = tied[0]

            child_topics = [ts for ts in top_topics if ts.row.route_to == top_child]
            child_topics.sort(key=lambda ts: ts.score, reverse=True)
            top_topic = child_topics[0].row.topic_node if child_topics else top_topics[0].row.topic_node

            if len(child_topics) > 1 and abs(child_topics[0].score - child_topics[1].score) <= tie_epsilon:
                tie_breakers_applied.append("topic_longest_phrase_then_required_vars_then_az")
                top_score_child = child_topics[0].score
                tied_topics = [ts for ts in child_topics if abs(ts.score - top_score_child) <= tie_epsilon]
                tied_topics.sort(
                    key=lambda ts: (
                        len(normalize_text(ts.matched_phrase)),
                        len(ts.row.required_variables),
                        ts.row.topic_node.lower(),
                    ),
                    reverse=True,
                )
                top_topic = tied_topics[0].row.topic_node

        cand_children: list[CandidateChild] = []
        for child, ts in candidates_sorted:
            evidence_keywords = sorted(list(tokens(request.user_intent_raw) & tokens(ts.matched_phrase)))
            cand_children.append(
                CandidateChild(
                    child=child,
                    score=ts.score,
                    reason=f"best_topic={ts.row.topic_node}",
                    evidence=CandidateChildEvidence(
                        matched_keywords=evidence_keywords,
                        matched_phrases=[ts.matched_phrase] if ts.matched_phrase else [],
                    ),
                )
            )

        cand_topics: list[CandidateTopic] = [
            CandidateTopic(
                topic_node=ts.row.topic_node,
                child=ts.row.route_to,
                score=ts.score,
                matched_phrase=ts.matched_phrase,
                match_type=ts.match_type,  # type: ignore[arg-type]
                required_variables_count=len(ts.row.required_variables),
            )
            for ts in top_topics
        ]

        needs_disambiguation = False
        disambiguation_question = None

        if top_score < confidence_threshold:
            needs_disambiguation = True
        if len(candidates_sorted) > 1 and abs(candidates_sorted[0][1].score - candidates_sorted[1][1].score) <= tie_epsilon:
            needs_disambiguation = True

        child_scores = [t.score for t in cand_topics if t.child == top_child]
        child_scores.sort(reverse=True)
        if len(child_scores) > 1 and abs(child_scores[0] - child_scores[1]) <= tie_epsilon:
            needs_disambiguation = True

        if needs_disambiguation:
            top2 = [c for c, _ in candidates_sorted[:2]]
            if "Maxey8" in top2:
                disambiguation_question = "Is this about security/compliance (DLP, auth, access control, privacy/PII, residency), or something else?"
            elif "Maxey9" in top2:
                disambiguation_question = "Is this about release/ALM (solutions, versioning, import/export, pipelines, rollback), or something else?"
            else:
                disambiguation_question = "Which area is this: Knowledge, Data, Actions, Integrations, Channels, Quality, Admin, Security, or ALM?"

        return ClassifyRoutingResponse(
            request_id=request.request_id,
            routing_table_version=request.routing_table_version,
            top_child=top_child,
            top_topic_node=top_topic,
            top_score=float(top_score),
            needs_disambiguation=needs_disambiguation,
            disambiguation_question=disambiguation_question,
            candidate_children=cand_children,
            candidate_topics=cand_topics,
            explainability=Explainability(
                tie_breakers_applied=tie_breakers_applied,
                thresholds_used={"confidence_threshold": confidence_threshold, "tie_epsilon": tie_epsilon},
                precedence_order=_PRECEDENCE,
            ),
        )
