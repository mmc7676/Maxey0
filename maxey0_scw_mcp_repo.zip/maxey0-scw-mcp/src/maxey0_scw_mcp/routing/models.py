from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field


class ClassifyRoutingOptions(BaseModel):
    max_candidate_children: int = Field(default=5, ge=1, le=9)
    max_candidate_topics: int = Field(default=10, ge=1, le=50)
    confidence_threshold: float = Field(default=0.55, ge=0, le=1)
    tie_epsilon: float = Field(default=0.05, ge=0, le=1)


class ClassifyRoutingRequest(BaseModel):
    request_id: str = Field(min_length=1)
    user_intent_raw: str = Field(min_length=1)
    routing_table_version: str = Field(min_length=1)
    timestamp_utc: str | None = None
    conversation_context: dict[str, Any] | None = None
    options: ClassifyRoutingOptions | None = None


MatchType = Literal["exact_phrase", "contains_phrase", "keyword_overlap"]


class CandidateChildEvidence(BaseModel):
    matched_keywords: list[str]
    matched_phrases: list[str]


class CandidateChild(BaseModel):
    child: str
    score: float = Field(ge=0, le=1)
    reason: str
    evidence: CandidateChildEvidence


class CandidateTopic(BaseModel):
    topic_node: str
    child: str
    score: float = Field(ge=0, le=1)
    matched_phrase: str
    match_type: MatchType
    required_variables_count: int = Field(ge=0)


class Explainability(BaseModel):
    tie_breakers_applied: list[str]
    thresholds_used: dict[str, float]
    precedence_order: list[str]


class ClassifyRoutingResponse(BaseModel):
    request_id: str
    routing_table_version: str
    top_child: str
    top_topic_node: str
    top_score: float = Field(ge=0, le=1)
    needs_disambiguation: bool
    disambiguation_question: str | None = None
    candidate_children: list[CandidateChild]
    candidate_topics: list[CandidateTopic]
    explainability: Explainability
