from __future__ import annotations

import re

_RX_PUNCT = re.compile(r"[^a-z0-9\s]+", re.IGNORECASE)
_RX_WS = re.compile(r"\s+")


def normalize_text(s: str) -> str:
    s = s.lower()
    s = _RX_PUNCT.sub(" ", s)
    s = _RX_WS.sub(" ", s).strip()
    return s


def tokens(s: str) -> set[str]:
    s = normalize_text(s)
    return set(s.split()) if s else set()
