from __future__ import annotations

import argparse
import sys

from maxey0_scw_mcp.logging import configure_logging
from maxey0_scw_mcp.server_entry import build_server


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="maxey0mcp", add_help=True)
    parser.add_argument("--transport", choices=["stdio", "streamable-http"], default="stdio")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8787)
    args = parser.parse_args(argv)

    configure_logging(transport=args.transport)
    server = build_server()

    if args.transport == "stdio":
        server.run(transport="stdio")
        return 0

    server.run(transport="streamable-http", host=args.host, port=args.port)
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
