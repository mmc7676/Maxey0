from __future__ import annotations

from typing import Any

from mcp.server.fastmcp import FastMCP

from maxey0_scw_mcp.config import load_config
from maxey0_scw_mcp.routing.classify import ClassifyRoutingEngine, ClassifyRoutingRequest
from maxey0_scw_mcp.scw.runtime import (
    SCWCheckpointRequest,
    SCWCreateRequest,
    SCWExecRequest,
    SCWRuntime,
    SCWSealRequest,
)


def build_server() -> FastMCP:
    cfg = load_config()
    mcp = FastMCP("Maxey0", json_response=True)

    routing = ClassifyRoutingEngine.from_csv(cfg.routing_table_path)
    scw = SCWRuntime(cfg=cfg)

    @mcp.tool(name="maxey0.route.classify", description="Deterministic routing (Maxey0 -> Maxey1..Maxey9).")
    def maxey0_route_classify(request: dict[str, Any]) -> dict[str, Any]:
        parsed = ClassifyRoutingRequest.model_validate(request)
        return routing.classify(parsed).model_dump()

    @mcp.tool(name="maxey0.scw.create", description="Create a new SCW capsule.")
    def maxey0_scw_create(request: dict[str, Any]) -> dict[str, Any]:
        parsed = SCWCreateRequest.model_validate(request)
        return scw.create(parsed).model_dump()

    @mcp.tool(name="maxey0.scw.checkpoint", description="Record a checkpoint (best-guess decision) into an SCW log.")
    def maxey0_scw_checkpoint(request: dict[str, Any]) -> dict[str, Any]:
        parsed = SCWCheckpointRequest.model_validate(request)
        return scw.checkpoint(parsed).model_dump()

    @mcp.tool(name="maxey0.scw.exec", description="Execute a command inside an SCW sandbox (Docker, network-disabled).")
    def maxey0_scw_exec(request: dict[str, Any]) -> dict[str, Any]:
        parsed = SCWExecRequest.model_validate(request)
        return scw.exec(parsed).model_dump()

    @mcp.tool(name="maxey0.scw.seal", description="Seal an SCW transcript with hash-chain evidence digests.")
    def maxey0_scw_seal(request: dict[str, Any]) -> dict[str, Any]:
        parsed = SCWSealRequest.model_validate(request)
        return scw.seal(parsed).model_dump()

    @mcp.resource("maxey0://scw/{scw_id}/manifest")
    def maxey0_scw_manifest(scw_id: str) -> str:
        return scw.read_manifest_text(scw_id)

    @mcp.resource("maxey0://scw/{scw_id}/log")
    def maxey0_scw_log(scw_id: str) -> str:
        return scw.read_log_text(scw_id)

    @mcp.prompt(name="maxey0.scw.run", description="How to use SCWs with Maxey0 tools.")
    def maxey0_scw_run_prompt(task: str, constraints: str = "") -> str:
        return (
            "You are using Maxey0 SCWs as on-demand execution capsules.\n"
            "1) Call maxey0.scw.create to get scw_id.\n"
            "2) Record key decisions with maxey0.scw.checkpoint.\n"
            "3) Execute sandboxed steps with maxey0.scw.exec.\n"
            "4) Seal the run with maxey0.scw.seal.\n\n"
            f"Task: {task}\nConstraints: {constraints}\n"
        )

    return mcp
