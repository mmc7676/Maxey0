from __future__ import annotations

import sys

from maxey0_scw_mcp.cli import main

if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
