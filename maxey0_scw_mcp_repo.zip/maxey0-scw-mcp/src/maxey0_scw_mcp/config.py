from __future__ import annotations

from pydantic_settings import BaseSettings, SettingsConfigDict


class Maxey0Config(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="MAXEY0_", extra="ignore")

    data_dir: str = ".maxey0"
    sandbox_enabled: bool = True
    sandbox_image: str = "python:3.11-slim"
    sandbox_network: str = "none"
    sandbox_cpus: float = 1.0
    sandbox_memory: str = "512m"
    sandbox_pids_limit: int = 256
    sandbox_timeout_s: int = 60

    routing_table_path: str = "data/routing/maxey0_parent_routing_table.csv"


def load_config() -> Maxey0Config:
    return Maxey0Config()
