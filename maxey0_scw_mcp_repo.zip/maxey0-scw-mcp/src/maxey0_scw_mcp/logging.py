from __future__ import annotations

import logging
import os
import sys
from typing import Final

_LOG_LEVEL_DEFAULT: Final[str] = "INFO"


def configure_logging(*, transport: str) -> None:
    level = os.getenv("MAXEY0_LOG_LEVEL", _LOG_LEVEL_DEFAULT).upper()
    handler = logging.StreamHandler(stream=sys.stderr if transport == "stdio" else sys.stdout)
    formatter = logging.Formatter(
        fmt="%(asctime)sZ %(levelname)s %(name)s :: %(message)s",
        datefmt="%Y-%m-%dT%H:%M:%S",
    )
    handler.setFormatter(formatter)

    root = logging.getLogger()
    root.handlers.clear()
    root.addHandler(handler)
    root.setLevel(level)
