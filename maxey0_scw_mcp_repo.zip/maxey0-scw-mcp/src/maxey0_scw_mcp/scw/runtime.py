from __future__ import annotations

import base64
import platform
import secrets
from datetime import datetime, timezone
from typing import Any

from pydantic import BaseModel, Field

from maxey0_scw_mcp.config import Maxey0Config
from maxey0_scw_mcp.scw.sandbox import DockerSandbox
from maxey0_scw_mcp.scw.store import SCWStore
from maxey0_scw_mcp.util.hash import sha256_json, sha256_text


def _utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


class SCWCreateRequest(BaseModel):
    title: str = Field(min_length=1)


class SCWCreateResponse(BaseModel):
    scw_id: str
    run_id: str
    title: str
    created_utc: str


class SCWCheckpointRequest(BaseModel):
    scw_id: str = Field(min_length=1)
    label: str = Field(min_length=1)
    best_guess: str = Field(min_length=1)
    evidence: dict[str, Any] = Field(default_factory=dict)


class SCWCheckpointResponse(BaseModel):
    scw_id: str
    checkpoint_id: str
    checkpoint_digest: str


class SCWExecFile(BaseModel):
    path: str = Field(min_length=1)
    content_base64: str = Field(min_length=1)


class SCWExecRequest(BaseModel):
    scw_id: str = Field(min_length=1)
    seq: int = Field(ge=0)
    command: list[str] = Field(min_length=1)
    env: dict[str, str] = Field(default_factory=dict)
    files: list[SCWExecFile] = Field(default_factory=list)


class SCWExecResponse(BaseModel):
    scw_id: str
    tick_id: str
    op_digest: str
    exit_code: int
    stdout: str
    stderr: str


class SCWSealRequest(BaseModel):
    scw_id: str = Field(min_length=1)


class SCWSealResponse(BaseModel):
    scw_id: str
    manifest_digest: str
    log_digest: str
    sealed_utc: str


class SCWRuntime:
    def __init__(self, *, cfg: Maxey0Config):
        self.cfg = cfg
        self.store = SCWStore(cfg.data_dir)
        self.sandbox = DockerSandbox(
            image=cfg.sandbox_image,
            network=cfg.sandbox_network,
            cpus=cfg.sandbox_cpus,
            memory=cfg.sandbox_memory,
            pids_limit=cfg.sandbox_pids_limit,
            timeout_s=cfg.sandbox_timeout_s,
        )

    def create(self, req: SCWCreateRequest) -> SCWCreateResponse:
        scw_id = self.store.new_scw_id()
        run_id = f"run_{secrets.token_hex(8)}"
        self.store.write_json(
            scw_id,
            "manifest.json",
            {
                "title": req.title,
                "created_utc": _utc_now(),
                "sealed": False,
                "host_runtime": {"python": platform.python_version()},
            },
        )
        return SCWCreateResponse(scw_id=scw_id, run_id=run_id, title=req.title, created_utc=_utc_now())

    def checkpoint(self, req: SCWCheckpointRequest) -> SCWCheckpointResponse:
        checkpoint_id = f"cp_{secrets.token_hex(8)}"
        payload = {
            "type": "checkpoint",
            "checkpoint_id": checkpoint_id,
            "utc": _utc_now(),
            "label": req.label,
            "best_guess": req.best_guess,
            "evidence": req.evidence,
        }
        digest = self.store.append_jsonl(req.scw_id, "log.jsonl", payload)
        return SCWCheckpointResponse(scw_id=req.scw_id, checkpoint_id=checkpoint_id, checkpoint_digest=digest)

    def exec(self, req: SCWExecRequest) -> SCWExecResponse:
        if not self.cfg.sandbox_enabled:
            raise RuntimeError("sandbox_disabled")
        workdir = self.store.workspace_dir(req.scw_id)

        file_digests: list[dict[str, Any]] = []
        for f in req.files:
            data = base64.b64decode(f.content_base64.encode("utf-8"))
            digest = self.store.write_file(req.scw_id, f.path, data)
            file_digests.append({"path": f.path, "sha256": digest, "bytes": len(data)})

        tick_id = f"tick_{req.seq:06d}_{secrets.token_hex(4)}"
        result = self.sandbox.run(workdir=workdir, command=req.command, env=req.env)

        op = {
            "command": req.command,
            "env_keys": sorted(list(req.env.keys())),
            "files": file_digests,
            "exit_code": result.exit_code,
            "stdout_sha256": sha256_text(result.stdout),
            "stderr_sha256": sha256_text(result.stderr),
        }
        op_digest = sha256_json(op)

        self.store.append_jsonl(
            req.scw_id,
            "log.jsonl",
            {"type": "tick", "tick_id": tick_id, "seq": req.seq, "op": op, "op_digest": op_digest},
        )
        return SCWExecResponse(
            scw_id=req.scw_id,
            tick_id=tick_id,
            op_digest=op_digest,
            exit_code=result.exit_code,
            stdout=result.stdout,
            stderr=result.stderr,
        )

    def seal(self, req: SCWSealRequest) -> SCWSealResponse:
        log_text = self.store.read_text(req.scw_id, "log.jsonl")
        log_digest = sha256_text(log_text)

        manifest = {"sealed": True, "sealed_utc": _utc_now(), "log_sha256": log_digest}
        manifest_digest = self.store.write_json(req.scw_id, "sealed_manifest.json", manifest)
        self.store.append_jsonl(req.scw_id, "log.jsonl", {"type": "seal", **manifest})

        return SCWSealResponse(scw_id=req.scw_id, manifest_digest=manifest_digest, log_digest=log_digest, sealed_utc=manifest["sealed_utc"])

    def read_manifest_text(self, scw_id: str) -> str:
        return self.store.read_text(scw_id, "sealed_manifest.json") or self.store.read_text(scw_id, "manifest.json")

    def read_log_text(self, scw_id: str) -> str:
        return self.store.read_text(scw_id, "log.jsonl")
