from __future__ import annotations

import json
import secrets
from pathlib import Path
from typing import Any

from maxey0_scw_mcp.util.hash import sha256_bytes, sha256_json

_SCW_DIRNAME = "scw"


class SCWStore:
    def __init__(self, base_dir: str):
        self.base_dir = Path(base_dir).expanduser().resolve()
        self.scw_root = self.base_dir / _SCW_DIRNAME
        self.scw_root.mkdir(parents=True, exist_ok=True)

    def new_scw_id(self) -> str:
        return f"SCW{secrets.randbelow(10**9):09d}"

    def scw_dir(self, scw_id: str) -> Path:
        p = (self.scw_root / scw_id).resolve()
        if self.scw_root not in p.parents and p != self.scw_root:
            raise ValueError("Invalid scw_id path traversal")
        p.mkdir(parents=True, exist_ok=True)
        return p

    def write_json(self, scw_id: str, name: str, obj: Any) -> str:
        p = self.scw_dir(scw_id) / name
        data = json.dumps(obj, indent=2, sort_keys=True).encode("utf-8")
        p.write_bytes(data)
        return sha256_bytes(data)

    def append_jsonl(self, scw_id: str, name: str, obj: Any) -> str:
        p = self.scw_dir(scw_id) / name
        line = json.dumps(obj, sort_keys=True, separators=(",", ":")) + "\n"
        p.open("a", encoding="utf-8", newline="").write(line)
        return sha256_json(obj)

    def read_text(self, scw_id: str, name: str) -> str:
        p = self.scw_dir(scw_id) / name
        return p.read_text(encoding="utf-8") if p.exists() else ""

    def write_file(self, scw_id: str, relpath: str, data: bytes) -> str:
        p = self.scw_dir(scw_id) / "workspace" / relpath
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(data)
        return sha256_bytes(data)

    def workspace_dir(self, scw_id: str) -> Path:
        p = self.scw_dir(scw_id) / "workspace"
        p.mkdir(parents=True, exist_ok=True)
        return p
