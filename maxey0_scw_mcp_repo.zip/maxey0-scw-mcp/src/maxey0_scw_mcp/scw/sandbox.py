from __future__ import annotations

import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Sequence


@dataclass(frozen=True)
class SandboxResult:
    exit_code: int
    stdout: str
    stderr: str


class DockerSandbox:
    def __init__(
        self,
        *,
        image: str,
        network: str,
        cpus: float,
        memory: str,
        pids_limit: int,
        timeout_s: int,
    ):
        self.image = image
        self.network = network
        self.cpus = cpus
        self.memory = memory
        self.pids_limit = pids_limit
        self.timeout_s = timeout_s

    def ensure_available(self) -> None:
        if shutil.which("docker") is None:
            raise RuntimeError("docker_not_installed")

    def run(self, *, workdir: Path, command: Sequence[str], env: dict[str, str] | None = None) -> SandboxResult:
        self.ensure_available()
        env = env or {}
        docker_cmd = [
            "docker",
            "run",
            "--rm",
            "--network",
            self.network,
            "--cpus",
            str(self.cpus),
            "--memory",
            self.memory,
            "--pids-limit",
            str(self.pids_limit),
            "-v",
            f"{str(workdir)}:/work",
            "-w",
            "/work",
        ]
        for k, v in env.items():
            docker_cmd.extend(["-e", f"{k}={v}"])
        docker_cmd.append(self.image)
        docker_cmd.extend(command)

        proc = subprocess.run(
            docker_cmd,
            capture_output=True,
            text=True,
            timeout=self.timeout_s,
            check=False,
        )
        return SandboxResult(exit_code=proc.returncode, stdout=proc.stdout, stderr=proc.stderr)
