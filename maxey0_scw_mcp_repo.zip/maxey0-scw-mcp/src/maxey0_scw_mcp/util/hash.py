from __future__ import annotations

import hashlib
from typing import Any

import orjson


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_text(text: str) -> str:
    return sha256_bytes(text.encode("utf-8"))


def canonical_json_bytes(obj: Any) -> bytes:
    return orjson.dumps(obj, option=orjson.OPT_SORT_KEYS)


def sha256_json(obj: Any) -> str:
    return sha256_bytes(canonical_json_bytes(obj))
