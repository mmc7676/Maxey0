#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DIST="$ROOT/dist"
BUNDLE_DIR="$ROOT/.mcpb_build"

rm -rf "$BUNDLE_DIR"
mkdir -p "$BUNDLE_DIR" "$DIST"

cp "$ROOT/mcpb/manifest.uv.json" "$BUNDLE_DIR/manifest.json"
cp "$ROOT/mcpb/.mcpbignore" "$BUNDLE_DIR/.mcpbignore"
cp "$ROOT/pyproject.toml" "$BUNDLE_DIR/pyproject.toml"
mkdir -p "$BUNDLE_DIR/src"
rsync -a --delete "$ROOT/src/" "$BUNDLE_DIR/src/"

mcpb pack "$BUNDLE_DIR" --output "$DIST/maxey0-scw.mcpb"

echo "Built: $DIST/maxey0-scw.mcpb"
