from __future__ import annotations

import json
from pathlib import Path

from maxey0_scw_mcp.routing.classify import ClassifyRoutingEngine
from maxey0_scw_mcp.routing.models import ClassifyRoutingRequest


def test_classify_routing_vectors() -> None:
    engine = ClassifyRoutingEngine.from_csv("data/routing/maxey0_parent_routing_table.csv", routing_table_version="v1")
    vectors = json.loads(Path("tests/data/maxey0_classifyrouting_tests.json").read_text(encoding="utf-8"))

    for v in vectors:
        req = ClassifyRoutingRequest.model_validate(v["request"])
        res = engine.classify(req)
        assert res.top_child == v["expected"]["top_child"], v["name"]
        assert res.needs_disambiguation == v["expected"]["needs_disambiguation"], v["name"]
