from __future__ import annotations

import pytest

from maxey0_scw_mcp.config import Maxey0Config
from maxey0_scw_mcp.scw.runtime import SCWCreateRequest, SCWExecRequest, SCWRuntime


def test_scw_exec_blocked_when_sandbox_disabled(tmp_path) -> None:
    cfg = Maxey0Config(data_dir=str(tmp_path), sandbox_enabled=False)
    rt = SCWRuntime(cfg=cfg)
    created = rt.create(SCWCreateRequest(title="t"))

    with pytest.raises(RuntimeError):
        rt.exec(SCWExecRequest(scw_id=created.scw_id, seq=0, command=["python", "-c", "print('x')"]))
