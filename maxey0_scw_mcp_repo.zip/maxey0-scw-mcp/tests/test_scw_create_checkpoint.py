from __future__ import annotations

from maxey0_scw_mcp.config import Maxey0Config
from maxey0_scw_mcp.scw.runtime import SCWCheckpointRequest, SCWCreateRequest, SCWRuntime


def test_scw_create_and_checkpoint(tmp_path) -> None:
    cfg = Maxey0Config(data_dir=str(tmp_path), sandbox_enabled=False)
    rt = SCWRuntime(cfg=cfg)

    created = rt.create(SCWCreateRequest(title="t"))
    cp = rt.checkpoint(SCWCheckpointRequest(scw_id=created.scw_id, label="d", best_guess="x"))

    assert cp.scw_id == created.scw_id
    assert "checkpoint" in rt.read_log_text(created.scw_id)
