# Codex Assembly Brief: maxey0-scw-mcp

Goal: take this repo and harden it into a publishable MCPB/Claude Desktop extension and a cloud-deployable MCP server.

## What is already done
- MCP server implemented with official MCP Python SDK FastMCP.
- Deterministic routing tool: `maxey0.route.classify` (CSV-driven + normative tie-breaks).
- SCW capsule runtime:
  - `maxey0.scw.create`
  - `maxey0.scw.checkpoint`
  - `maxey0.scw.exec` (Docker, network disabled)
  - `maxey0.scw.seal` (log digest + sealed manifest)
  - resources for manifest/log
- CI: lint/typecheck/tests + docker build.

## What to do next (ordered)
1) **Audit correctness vs your contract schemas**
   - Validate `maxey0.route.classify` response against `contracts/classify-routing.schema.json`.
   - Validate tools & outputs vs `contracts/maxey0_routing_actions.openapi.json`.

2) **SCW determinism upgrades**
   - Add full tick structure (pre/post conditions, op_digests, artifact digests).
   - Add hash-chain (prev_hash) per log entry; store merkle root (optional).
   - Add environment fingerprint fields.

3) **Policy gating**
   - Add per-SCW policy gates: allowed tools, token budgets, sandbox limits.
   - Add server-level allow/deny lists for tools to expose.

4) **Sandbox hardening**
   - Add read-only root FS, tmpfs, no-new-privileges, seccomp profile.
   - Add CPU/mem/timeouts enforcement at both Docker and app levels.

5) **MCPB packaging**
   - Confirm `manifest_version` & `server.type="uv"` compatibility with current Claude Desktop.
   - Produce `dist/maxey0-scw.mcpb` and add a release workflow.

## Non-goals (do not implement)
- Any speculative Claude Desktop behaviors not evidenced by cited docs.
- Networked code execution without explicit policy & audit trail.

## Local smoke test
- `uv sync --all-extras --dev`
- `make run-http` then connect MCP Inspector to `http://localhost:8787/mcp`
- `make run-stdio` and connect via Claude Desktop config
